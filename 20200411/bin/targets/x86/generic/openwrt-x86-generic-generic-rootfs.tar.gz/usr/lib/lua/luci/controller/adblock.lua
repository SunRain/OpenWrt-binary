module("luci.controller.adblock",package.seeall)
local e=require("luci.util")
local o=require("luci.template")
local a=require("luci.i18n")
function index()
if not nixio.fs.access("/etc/config/adblock")then
return
end
entry({"admin","services","adblock"},firstchild(),_("Adblock"),30).dependent=false
entry({"admin","services","adblock","tab_from_cbi"},cbi("adblock/overview_tab",{hideresetbtn=true,hidesavebtn=true}),_("Overview"),10).leaf=true
entry({"admin","services","adblock","logfile"},call("logread"),_("View Logfile"),20).leaf=true
entry({"admin","services","adblock","advanced"},firstchild(),_("Advanced"),100)
entry({"admin","services","adblock","advanced","blacklist"},form("adblock/blacklist_tab"),_("Edit Blacklist"),110).leaf=true
entry({"admin","services","adblock","advanced","whitelist"},form("adblock/whitelist_tab"),_("Edit Whitelist"),120).leaf=true
entry({"admin","services","adblock","advanced","configuration"},form("adblock/configuration_tab"),_("Edit Configuration"),130).leaf=true
entry({"admin","services","adblock","advanced","query"},template("adblock/query"),_("Query domains"),140).leaf=true
entry({"admin","services","adblock","advanced","result"},call("queryData"),nil,150).leaf=true
end
function logread()
local t
if nixio.fs.access("/var/log/messages")then
t=e.trim(e.exec("grep -F 'adblock-' /var/log/messages"))
else
t=e.trim(e.exec("logread -e 'adblock-'"))
end
o.render("adblock/logread",{title=a.translate("Adblock Logfile"),content=t})
end
function queryData(t)
if t then
luci.http.prepare_content("text/plain")
local a="/etc/init.d/adblock query %s 2>&1"
local e=io.popen(a%e.shellquote(t))
if e then
while true do
local e=e:read("*l")
if not e then
break
end
luci.http.write(e)
luci.http.write("\n")
end
e:close()
end
end
end

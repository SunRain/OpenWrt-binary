module("luci.controller.aria2",package.seeall)
function index()
if not nixio.fs.access("/etc/config/aria2")then
return
end
local e=entry({"admin","services","aria2"},cbi("aria2"),_("Aria2 Settings"))
e.dependent=true
entry({"admin","services","aria2","status"},call("status")).leaf=true
end
function status()
local a=require"luci.sys"
local e=require"luci.model.ipkg"
local t=require"luci.http"
local o=require"luci.model.uci".cursor()
local e={
running=(a.call("pidof aria2c > /dev/null")==0),
yaaw=e.installed("yaaw"),
webui=e.installed("webui-aria2"),
ariang=(e.installed("ariang")or e.installed("ariang-nginx"))
}
t.prepare_content("application/json")
t.write_json(e)
end

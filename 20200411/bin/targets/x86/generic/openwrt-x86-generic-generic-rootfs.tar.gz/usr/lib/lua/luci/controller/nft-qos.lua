module("luci.controller.nft-qos",package.seeall)
function index()
if not nixio.fs.access("/etc/config/nft-qos")then
return
end
entry({"admin","status","realtime","rate"},
template("nft-qos/rate"),_("Rate"),5).leaf=true
entry({"admin","status","realtime","rate_status"},
call("action_rate")).leaf=true
entry({"admin","services","nft-qos"},cbi("nft-qos/nft-qos"),
_("Qos over Nftables"),60)
end
function _action_rate(o,e)
local t=nixio.fs.access("/proc/net/ipv6_route")and
io.popen("nft list chain inet nft-qos-monitor "..e.." 2>/dev/null")or
io.popen("nft list chain ip nft-qos-monitor "..e.." 2>/dev/null")
if t then
for a in t:lines()do
local n,a,t,i=a:match(
'^%s+ip ([^%s]+) ([^%s]+) counter packets (%d+) bytes (%d+)'
)
if a and t and i then
o[#o+1]={
rule={
family="inet",
table="nft-qos-monitor",
chain=e,
handle=0,
expr={
{match={right=a}},
{counter={packets=t,bytes=i}}
}
}
}
end
end
t:close()
end
end
function action_rate()
luci.http.prepare_content("application/json")
local e={nftables={}}
_action_rate(e.nftables,"upload")
_action_rate(e.nftables,"download")
luci.http.write_json(e)
end

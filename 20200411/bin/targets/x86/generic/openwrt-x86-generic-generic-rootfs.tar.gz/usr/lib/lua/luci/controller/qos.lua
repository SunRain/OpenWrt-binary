module("luci.controller.qos",package.seeall)
function index()
if not nixio.fs.access("/etc/config/qos")then
return
end
local e
e=entry({"admin","network","qos"},cbi("qos/qos"),_("QoS"))
e.dependent=true
end

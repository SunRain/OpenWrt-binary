local e=require("nixio.fs")
local a=require("luci.util")
local e=require("luci.model.uci").cursor()
local e=e:get("adblock","blacklist","adb_src")or"/etc/adblock/adblock.blacklist"
if not nixio.fs.access(e)then
m=SimpleForm("error",nil,
translate("Input file not found, please check your configuration."))
m.reset=false
m.submit=false
return m
end
if nixio.fs.stat(e).size>524288 then
m=SimpleForm("error",nil,
translate("The file size is too large for online editing in LuCI (&gt; 512 KB). ")
..translate("Please edit this file directly in a terminal session."))
m.reset=false
m.submit=false
return m
end
m=SimpleForm("input",nil)
m:append(Template("adblock/config_css"))
m.submit=translate("Save")
m.reset=false
s=m:section(SimpleSection,nil,
translatef("This form allows you to modify the content of the adblock blacklist (%s).<br />",e)
..translate("Please add only one domain per line. Comments introduced with '#' are allowed - ip addresses, wildcards and regex are not."))
f=s:option(TextValue,"data")
f.datatype="string"
f.rows=20
f.rmempty=true
function f.cfgvalue()
return nixio.fs.readfile(e)or""
end
function f.write(o,o,t)
return nixio.fs.writefile(e,"\n"..a.trim(t:gsub("\r\n","\n")).."\n")
end
function s.handle(e,e,e)
return true
end
return m

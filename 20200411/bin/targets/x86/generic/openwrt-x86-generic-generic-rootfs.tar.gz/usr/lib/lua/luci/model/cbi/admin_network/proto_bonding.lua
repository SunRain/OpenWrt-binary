local t,e,t=...
local j,s,t,t
local I=require"luci.sys"
local t,p,a,i,n,_,E,T
local r,l,A,u,c,d
local z,t,v,x,h
local b,f,w,o,g,k,q,y
local function O(i)
m.uci:foreach("network","interface",
function(e)
if e[".name"]~="loopback"then
local e=m.uci:get("network",e['.name'],"ifname")
local o=false
m.uci:foreach("network","interface",
function(t)
if m.uci:get("network",t['.name'],"proto")=="bonding"then
local a=m.uci:get("network",t['.name'],"slaves")
if a~=nil then
for a in a:gmatch("[%S-]+")do
if e==a:gsub("-","")and t['.name']~=arg[1]then
o=true
end
end
end
end
end
)
if o==false and e~=nil then
if e:find("eth")~=nil then
i:value(e,e)
end
end
end
end
)
end
local function O(i)
local e=I.exec("cat /proc/net/dev | grep 'eth' | awk '\{print \$1\}' | tr ':\n' ' '")
if e~=nil then
for e in e:gmatch("[%S-]+")do
local o=false
m.uci:foreach("network","interface",
function(t)
if m.uci:get("network",t['.name'],"proto")=="bonding"then
local a=m.uci:get("network",t['.name'],"slaves")
if a~=nil then
for a in a:gmatch("[%S-]+")do
if e==a and t['.name']~=arg[1]then
o=true
end
end
end
end
end
)
if o==false then
i:value(e,e)
end
end
end
end
j=e:taboption("general",Value,"ipaddr",
translate("IPv4 address"))
j.datatype="ip4addr"
j.optional=false
j.rmempty=false
s=e:taboption("general",Value,"netmask",
translate("IPv4 netmask"))
s.datatype="ip4addr"
s.optional=false
s.rmempty=false
s:value("255.255.255.0")
s:value("255.255.0.0")
s:value("255.0.0.0")
p=e:taboption("advanced",MultiValue,"slaves",
translate("Slave Interfaces"),
translate("Specifies which slave interfaces should be attached to this bonding interface"))
p.oneline=true
p.widget="checkbox"
O(p)
a=e:taboption("advanced",ListValue,"bonding_policy",
translate("Bonding Policy"),
translate("Specifies the mode to be used for this bonding interface"))
a.default="balance-rr"
a:value("balance-rr",translate("Round-Robin policy (balance-rr, 0)"))
a:value("active-backup",translate("Active-Backup policy (active-backup, 1)"))
a:value("balance-xor",translate("XOR policy (balance-xor, 2)"))
a:value("broadcast",translate("Broadcast policy (broadcast, 3)"))
a:value("802.3ad",translate("IEEE 802.3ad Dynamic link aggregation (802.3ad, 4)"))
a:value("balance-tlb",translate("Adaptive transmit load balancing (balance-tlb, 5)"))
a:value("balance-alb",translate("Adaptive load balancing (balance-alb, 6)"))
i=e:taboption("advanced",ListValue,"primary",
translate("Primary Slave"),
translate("Specifies which slave is the primary device. It will always be the active slave while it is available"))
i.widget="radio"
i.orientation="horizontal"
i:depends("bonding_policy","active-backup")
i:depends("bonding_policy","balance-tlb")
i:depends("bonding_policy","balance-alb")
O(i)
n=e:taboption("advanced",ListValue,"primary_reselect",
translate("Reselection policy for primary slave"),
translate("Specifies the reselection policy for the primary slave when failure of the active slave or recovery of the primary slave occurs"))
n.default="always"
n:value("always",translate("Primary becomes active slave whenever it comes back up (always, 0)"))
n:value("better",translate("Primary becomes active slave when it comes back up if speed and duplex better than current slave (better, 1)"))
n:value("failure",translate("Only if current active slave fails and the primary slave is up (failure, 2)"))
n:depends("bonding_policy","active-backup")
n:depends("bonding_policy","balance-tlb")
n:depends("bonding_policy","balance-alb")
_=e:taboption("advanced",Value,"min_links",
translate("Minimum Number of Links"),
translate("Specifies the minimum number of links that must be active before asserting carrier"))
_.datatype="uinteger"
_.default=0
_:depends("bonding_policy","802.3ad")
E=e:taboption("advanced",Value,"ad_actor_sys_prio",
translate("System Priority"),
translate("Specifies the system priority"))
E.datatype="range(1,65535)"
E.default=65535
E:depends("bonding_policy","802.3ad")
T=e:taboption("advanced",Value,"ad_actor_system",
translate("MAC Address For The Actor"),
translate("Specifies the mac-address for the actor in protocol packet exchanges (LACPDUs). If empty, masters' mac address defaults to system default"))
T.datatype="macaddr"
T.default=""
T:depends("bonding_policy","802.3ad")
r=e:taboption("advanced",ListValue,"ad_select",
translate("Aggregation Selection Logic"),
translate("Specifies the aggregation selection logic to use"))
r.default="stable"
r:value("stable",translate("Aggregator: All slaves down or has no slaves (stable, 0)"))
r:value("bandwidth",translate("Aggregator: Slave added/removed or state changes (bandwidth, 1)"))
r:value("count",translate("Aggregator: Chosen by the largest number of ports + slave added/removed or state changes (count, 2)"))
r:depends("bonding_policy","802.3ad")
l=e:taboption("advanced",ListValue,"lacp_rate",
translate("LACPDU Packets"),
translate("Specifies the rate in which the link partner will be asked to transmit LACPDU packets"))
l.default="slow"
l:value("slow",translate("Every 30 seconds (slow, 0)"))
l:value("fast",translate("Every second (fast, 1)"))
l:depends("bonding_policy","802.3ad")
A=e:taboption("advanced",Value,"packets_per_slave",
translate("Packets To Transmit Before Moving To Next Slave"),
translate("Specifies the number of packets to transmit through a slave before moving to the next one"))
A.datatype="range(0,65535)"
A.default=1
A:depends("bonding_policy","balance-rr")
u=e:taboption("advanced",Value,"lp_interval",
translate("Interval For Sending Learning Packets"),
translate("Specifies the number of seconds between instances where the bonding	driver sends learning packets to each slaves peer switch"))
u.datatype="range(1,2147483647)"
u.default=1
u:depends("bonding_policy","balance-tlb")
u:depends("bonding_policy","balance-alb")
c=e:taboption("advanced",ListValue,"tlb_dynamic_lb",
translate("Enable Dynamic Shuffling Of Flows"),
translate("Specifies whether to shuffle active flows across slaves based on the load"))
c.default="1"
c:value("1",translate("Yes"))
c:value("0",translate("No"))
c:depends("bonding_policy","balance-tlb")
d=e:taboption("advanced",ListValue,"fail_over_mac",
translate("Set same MAC Address to all slaves"),
translate("Specifies whether active-backup mode should set all slaves to the same MAC address at enslavement"))
d.default="none"
d:value("none",translate("Yes (none, 0)"))
d:value("active",translate("Set to currently active slave (active, 1)"))
d:value("follow",translate("Set to first slave added to the bond (follow, 2)"))
d:depends("bonding_policy","active-backup")
z=e:taboption("advanced",Value,"num_grat_arp__num_unsol_na",
translate("Number of peer notifications after failover event"),
translate("Specifies the number of peer notifications (gratuitous ARPs and unsolicited IPv6 Neighbor Advertisements) to be issued after a failover event"))
z.datatype="range(0,255)"
z.default=1
z:depends("bonding_policy","active-backup")
t=e:taboption("advanced",ListValue,"xmit_hash_policy",
translate("Transmit Hash Policy"),
translate("Selects the transmit hash policy to use for slave selection"))
t.default="layer2"
t:value("layer2",translate("Use XOR of hardware MAC addresses (layer2)"))
t:value("layer2+3",translate("Use XOR of hardware MAC addresses and IP addresses (layer2+3)"))
t:value("layer3+4",translate("Use upper layer protocol information (layer3+4)"))
t:value("encap2+3",translate("Use XOR of hardware MAC addresses and IP addresses, rely on skb_flow_dissect (encap2+3)"))
t:value("encap3+4",translate("Use upper layer protocol information, rely on skb_flow_dissect (encap3+4)"))
t:depends("bonding_policy","balance-rr")
t:depends("bonding_policy","active-backup")
t:depends("bonding_policy","balance-tlb")
t:depends("bonding_policy","balance-alb")
t:depends("bonding_policy","balance-xor")
v=e:taboption("advanced",Value,"resend_igmp",
translate("Number of IGMP membership reports"),
translate("Specifies the number of IGMP membership reports to be issued after a failover event in 200ms intervals"))
v.datatype="range(0,255)"
v.default=1
v:depends("bonding_policy","balance-tlb")
v:depends("bonding_policy","balance-alb")
x=e:taboption("advanced",ListValue,"all_slaves_active",
translate("Drop Duplicate Frames"),
translate("Specifies that duplicate frames (received on inactive ports) should be dropped or delivered"))
x.default="0"
x:value("0",translate("Yes"))
x:value("1",translate("No"))
h=e:taboption("advanced",ListValue,"link_monitoring",
translate("Link Monitoring"),
translate("Method of link monitoring"))
h.default="off"
h:value("off",translate("Off"))
h:value("arp",translate("ARP"))
h:value("mii",translate("MII"))
b=e:taboption("advanced",Value,"arp_interval",
translate("ARP Interval"),
translate("Specifies the ARP link monitoring frequency in milliseconds"))
b.datatype="uinteger"
b.default=0
b:depends("link_monitoring","arp")
f=e:taboption("advanced",DynamicList,"arp_ip_target",
translate("ARP IP Targets"),
translate("Specifies the IP addresses to use for ARP monitoring"))
f.datatype="ipaddr"
f.cast="string"
f:depends("link_monitoring","arp")
w=e:taboption("advanced",ListValue,"arp_all_targets",
translate("ARP mode to consider a slave as being up"),
translate("Specifies the quantity of ARP IP targets that must be reachable"))
w.default="any"
w:value("any",translate("Consider the slave up when any ARP IP target is reachable (any, 0)"))
w:value("all",translate("Consider the slave up when all ARP IP targets are reachable (all, 1)"))
w:depends({link_monitoring="arp",bonding_policy="active-backup"})
o=e:taboption("advanced",ListValue,"arp_validate",
translate("ARP Validation"),
translate("Specifies whether ARP probes and replies should be validated or non-ARP traffic should be filtered for link monitoring"))
o.default="filter"
o:value("none",translate("No validation or filtering "))
o:value("active",translate("Validation only for active slave"))
o:value("backup",translate("Validation only for backup slaves"))
o:value("all",translate("Validation for all slaves"))
o:value("filter",translate("Filtering for all slaves, no validation"))
o:value("filter_active",translate("Filtering for all slaves, validation only for active slave"))
o:value("filter_backup",translate("Filtering for all slaves, validation only for backup slaves"))
o:depends("link_monitoring","arp")
g=e:taboption("advanced",Value,"miimon",
translate("MII Interval"),
translate("Specifies the MII link monitoring frequency in milliseconds"))
g.datatype="uinteger"
g.default=0
g:depends("link_monitoring","mii")
k=e:taboption("advanced",Value,"downdelay",
translate("Down Delay"),
translate("Specifies the time in milliseconds to wait before disabling a slave after a link failure detection"))
k.datatype="uinteger"
k.default=0
k:depends("link_monitoring","mii")
q=e:taboption("advanced",Value,"updelay",
translate("Up Delay"),
translate("Specifies the time in milliseconds to wait before enabling a slave after a link recovery detection"))
q.datatype="uinteger"
q.default=0
q:depends("link_monitoring","mii")
y=e:taboption("advanced",ListValue,"use_carrier",
translate("Method to determine link status"),
translate("Specifies whether or not miimon should use MII or ETHTOOL ioctls vs. netif_carrier_ok()"))
y.default="1"
y:value("0",translate("MII / ETHTOOL ioctls"))
y:value("1",translate("netif_carrier_ok()"))
y:depends("link_monitoring","mii")
function a.validate(e,o,t)
local n=h:formvalue(t)
local s=f:formvalue(t)
local e=a:formvalue(t)
local a=p:formvalue(t)
local t=i:formvalue(t)
if n=="arp"then
if e=="802.3ad"or e=="balance-tlb"or e=="balance-alb"then
return nil,translate("ARP monitoring is not supported for the selected policy")
end
if#s==0 then
return nil,translate("You must select at least one ARP IP target if ARP monitoring is selected")
end
end
if a==nil then
return nil,translate("You must select at least one slave interface")
end
if e=="active-backup"or e=="balance-tlb"or e=="balance-alb"then
if t==nil then
return nil,translate("You must select a primary interface for the selected policy")
else
if(type(a)=="table")then
for a,e in pairs(a)do
if e==t then
return o
end
end
else
if a==t then
return o
end
end
end
return nil,translate("You must select a primary interface which is included in selected slave interfaces")
end
return o
end

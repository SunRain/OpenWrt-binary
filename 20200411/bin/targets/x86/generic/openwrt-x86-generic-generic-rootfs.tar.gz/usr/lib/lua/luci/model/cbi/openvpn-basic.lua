require("luci.ip")
require("luci.model.uci")
local o={
{ListValue,"verb",{0,1,2,3,4,5,6,7,8,9,10,11},translate("Set output verbosity")},
{Value,"nice",0,translate("Change process priority")},
{Value,"port",1194,translate("TCP/UDP port # for both local and remote")},
{ListValue,"dev_type",{"tun","tap"},translate("Type of used device")},
{Flag,"tun_ipv6",0,translate("Make tun device IPv6 capable")},
{Value,"ifconfig","10.200.200.3 10.200.200.1",translate("Set tun/tap adapter parameters")},
{Value,"server","10.200.200.0 255.255.255.0",translate("Configure server mode")},
{Value,"server_bridge","192.168.1.1 255.255.255.0 192.168.1.128 192.168.1.254",translate("Configure server bridge")},
{Flag,"nobind",0,translate("Do not bind to local address and port")},
{ListValue,"comp_lzo",{"yes","no","adaptive"},translate("Use fast LZO compression")},
{Value,"keepalive","10 60",translate("Helper directive to simplify the expression of --ping and --ping-restart in server mode configurations")},
{ListValue,"proto",{"udp","tcp-client","tcp-server"},translate("Use protocol")},
{Flag,"client",0,translate("Configure client mode")},
{Flag,"client_to_client",0,translate("Allow client-to-client traffic")},
{DynamicList,"remote","vpnserver.example.org",translate("Remote host name or ip address")},
{FileUpload,"secret","/etc/openvpn/secret.key",translate("Enable Static Key encryption mode (non-TLS)")},
{Value,"key_direction","1",translate("The key direction for 'tls-auth' and 'secret' options")},
{FileUpload,"pkcs12","/etc/easy-rsa/keys/some-client.pk12",translate("PKCS#12 file containing keys")},
{FileUpload,"ca","/etc/easy-rsa/keys/ca.crt",translate("Certificate authority")},
{FileUpload,"dh","/etc/easy-rsa/keys/dh1024.pem",translate("Diffie Hellman parameters")},
{FileUpload,"cert","/etc/easy-rsa/keys/some-client.crt",translate("Local certificate")},
{FileUpload,"key","/etc/easy-rsa/keys/some-client.key",translate("Local private key")},
}
local a=Map("openvpn")
local e=a:section(SimpleSection)
e.template="openvpn/pageswitch"
e.mode="basic"
e.instance=arg[1]
local t=a:section(NamedSection,arg[1],"openvpn")
for a,e in ipairs(o)do
local t=t:option(
e[1],e[2],
e[2],e[4]
)
t.optional=true
if e[1]==DummyValue then
t.value=e[3]
else
if e[1]==DynamicList then
function t.cfgvalue(...)
local e=AbstractValue.cfgvalue(...)
return(e and type(e)~="table")and{e}or e
end
end
if type(e[3])=="table"then
if t.optional then t:value("","-- remove --")end
for a,e in ipairs(e[3])do
e=tostring(e)
t:value(e)
end
t.default=tostring(e[3][1])
else
t.default=tostring(e[3])
end
end
for a=5,#e do
if type(e[a])=="table"then
t:depends(e[a])
end
end
end
return a

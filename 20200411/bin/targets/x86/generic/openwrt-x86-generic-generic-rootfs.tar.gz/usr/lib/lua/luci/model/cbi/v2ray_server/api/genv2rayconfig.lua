local e=require"luci.model.uci".cursor()
local i=require"luci.jsonc"
local t=arg[1]
local e=e:get_all("v2ray_server",t)
local t=nil
local a=nil
if e.protocol=="vmess"then
if e.VMess_id then
local a={}
for o=1,#e.VMess_id do
a[o]={
id=e.VMess_id[o],
level=tonumber(e.VMess_level),
alterId=tonumber(e.VMess_alterId)
}
end
t={clients=a}
end
elseif e.protocol=="socks"then
t={
auth=(e.socks_username==nil and e.socks_password==nil)and
"noauth"or"password",
accounts={
{
user=(e.socks_username==nil)and""or
e.socks_username,
pass=(e.socks_password==nil)and""or
e.socks_password
}
}
}
elseif e.protocol=="http"then
t={
allowTransparent=false,
accounts={
{
user=(e.http_username==nil)and""or
e.http_username,
pass=(e.http_password==nil)and""or
e.http_password
}
}
}
elseif e.protocol=="shadowsocks"then
t={
method=e.ss_method,
password=e.ss_password,
level=tonumber(e.ss_level),
network=e.ss_network,
ota=(e.ss_ota=='1')and true or false
}
end
if e.accept_lan==nil or e.accept_lan=="0"then
a={
domainStrategy="IPOnDemand",
rules={
{
type="field",
ip={"10.0.0.0/8","172.16.0.0/12","192.168.0.0/16"},
outboundTag="blocked"
}
}
}
end
local e={
log={
loglevel="warning"
},
inbound={
listen=(e.bind_local=="1")and"127.0.0.1"or nil,
port=tonumber(e.port),
protocol=e.protocol,
settings=t,
streamSettings=(e.protocol=="vmess")and{
network=e.transport,
security=(e.tls_enable=='1')and"tls"or"none",
tlsSettings=(e.tls_enable=='1')and{
allowInsecure=false,
disableSystemRoot=false,
certificates={
{
certificateFile=e.tls_certificateFile,
keyFile=e.tls_keyFile
}
}
}or nil,
kcpSettings=(e.transport=="mkcp")and{
mtu=tonumber(e.mkcp_mtu),
tti=tonumber(e.mkcp_tti),
uplinkCapacity=tonumber(e.mkcp_uplinkCapacity),
downlinkCapacity=tonumber(e.mkcp_downlinkCapacity),
congestion=(e.mkcp_congestion=="1")and true or false,
readBufferSize=tonumber(e.mkcp_readBufferSize),
writeBufferSize=tonumber(e.mkcp_writeBufferSize),
header={type=e.mkcp_guise}
}or nil,
wsSettings=(e.transport=="ws")and{
headers=(e.ws_host)and{Host=e.ws_host}or nil,
path=e.ws_path
}or nil,
httpSettings=(e.transport=="h2")and
{path=e.h2_path,host=e.h2_host}or nil,
quicSettings=(e.transport=="quic")and{
security=e.quic_security,
key=e.quic_key,
header={type=e.quic_guise}
}or nil
}or nil
},
outbound={protocol="freedom"},
outboundDetour={{protocol="blackhole",tag="blocked"}},
routing=a
}
print(i.stringify(e,1))

module("luci.model.cbi.v2ray_server.api.v2ray",package.seeall)
local h=require"nixio.fs"
local t=require"luci.sys"
local e=require"luci.model.uci".cursor()
local o=require"luci.util"
local a=require"luci.i18n"
local d=require"luci.model.ipkg"
local e="v2ray_server"
local w=
"https://api.github.com/repos/v2ray/v2ray-core/releases/latest"
local c="/usr/bin/wget"
local y={
"--no-check-certificate","--quiet","--timeout=100","--tries=3"
}
local r=300
local n=nil
local i=nil
local l=false
local function u(t,e)
e=e or 1
if t[e]~=nil then return t[e],u(t,e+1)end
end
local function s(r,h,o,i)
local a=require"os"
local e=require"nixio"
local s,n=e.pipe()
local t=e.fork()
if t>0 then
n:close()
if o or i then
local n=a.time()
while true do
if i and a.difftime(a.time(),n)>=i then
e.kill(t,e.const.SIGTERM)
return 1
end
if o then
local e=s:read(2048)
if e and#e>0 then
o(e)
end
end
local a,t,n=e.waitpid(t,"nohang")
if a and t=="exited"then return n end
if not o and i then e.nanosleep(1)end
end
else
local a,e,t=e.waitpid(t)
return a and e=="exited"and t
end
elseif t==0 then
e.dup(n,e.stdout)
s:close()
n:close()
e.exece(r,h,nil)
e.stdout:close()
a.exit(1)
end
end
local function p(i,e,t)
local a=table
local i=o.split(i,"[%.%-]",nil,true)
local o=o.split(t,"[%.%-]",nil,true)
local t=a.getn(i)
local a=a.getn(o)
if(t<a)then t=a end
for t=1,t,1 do
local a=i[t]or""
local t=o[t]or""
if e=="~="and(a~=t)then return true end
if(e=="<"or e=="<=")and(a<t)then return true end
if(e==">"or e==">=")and(a>t)then return true end
if(a~=t)then return false end
end
return not(e=="<"or e==">")
end
local function f()
local e=nixio.uname().machine or""
if h.access("/usr/lib/os-release")then
n=t.exec(
"echo -n `grep 'LEDE_BOARD' /usr/lib/os-release | awk -F '[\\042\\047]' '{print $2}'`")
end
if h.access("/etc/openwrt_release")then
i=t.exec(
"echo -n `grep 'DISTRIB_TARGET' /etc/openwrt_release | awk -F '[\\042\\047]' '{print $2}'`")
end
if e=="mips"then
if n and n~=""then
if string.match(n,"ramips")=="ramips"then
e="ramips"
else
e=t.exec("echo '"..n..
"' | grep -oE 'ramips|ar71xx'")
end
elseif i and i~=""then
if string.match(i,"ramips")=="ramips"then
e="ramips"
else
e=t.exec("echo '"..i..
"' | grep -oE 'ramips|ar71xx'")
end
end
end
return o.trim(e)
end
local function m(t)
local e=""
local a=""
if t=="x86_64"then
e="64"
elseif t=="aarch64"then
e="arm64"
elseif t=="ramips"then
e="mipsle"
elseif t=="ar71xx"then
e="mips"
elseif t:match("^i[%d]86$")then
e="32"
elseif t:match("^armv[5-8]")then
e="arm"
a=t:match("[5-8]")
if n and string.match(n,"bcm53xx")=="bcm53xx"then
a="5"
elseif i and string.match(i,"bcm53xx")==
"bcm53xx"then
a="5"
end
a="5"
if a=="7"then l=true end
end
return e,a
end
local function i(e)
local t=require"luci.jsonc"
local a={}
local e=luci.sys.exec(c..
" --no-check-certificate --timeout=10 -t 1 -O- "..
e)
if e==""then return{}end
return t.parse(e)or{}
end
function get_v2ray_file_path()return"/usr/bin/v2ray"end
function get_v2ray_version()
if get_v2ray_file_path()and get_v2ray_file_path()~=""then
if h.access(get_v2ray_file_path().."/v2ray")then
return luci.sys.exec("echo -n `"..get_v2ray_file_path()..
"/v2ray -version | awk '{print $2}' | sed -n 1P"..
"`")
end
end
return""
end
function to_check(e)
if not e or e==""then e=f()end
local s,e=m(e)
if s==""then
return{
code=1,
error=a.translate(
"Can't determine ARCH, or ARCH not supported.")
}
end
local e=i(w)
if e.tag_name==nil then
return{
code=1,
error=a.translate("Get remote version info failed.")
}
end
local o=e.tag_name:match("[^v]+")
local n=p(get_v2ray_version(),"<",
o)
local t,i
if n then
t=e.html_url
for t,e in ipairs(e.assets)do
if e.name and e.name:match("linux%-"..s)then
i=e.browser_download_url
break
end
end
end
if n and not i then
return{
code=1,
now_version=get_v2ray_version(),
version=o,
html_url=t,
error=a.translate(
"New version found, but failed to get new version download url.")
}
end
return{
code=0,
update=n,
now_version=get_v2ray_version(),
version=o,
url={html=t,download=i}
}
end
function to_download(e)
if not e or e==""then
return{code=1,error=a.translate("Download url is required.")}
end
t.call("/bin/rm -f /tmp/v2ray_download.*")
local t=o.trim(o.exec("mktemp -u -t v2ray_download.XXXXXX"))
local o=s(c,{"-O",t,e,u(y)},nil,
r)==0
if not o then
s("/bin/rm",{"-f",t})
return{
code=1,
error=a.translatef("File download failed or timed out: %s",e)
}
end
return{code=0,file=t}
end
function to_extract(e,i)
local i=d.installed("unzip")
if i==nil then
d.update()
d.install("unzip")
end
if not e or e==""or not h.access(e)then
return{code=1,error=a.translate("File path required.")}
end
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
local a=o.trim(o.exec("mktemp -d -t v2ray_extract.XXXXXX"))
local t={}
s("/usr/bin/unzip",{"-o",e,"-d",a},
function(e)t[#t+1]=e end)
local t=o.split(table.concat(t))
s("/bin/rm",{"-f",e})
return{code=0,file=a}
end
function to_move(o)
if not o or o==""then
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{code=1,error=a.translate("Client file is required.")}
end
local e=get_v2ray_file_path()
t.call("mkdir -p "..e)
if not arch or arch==""then arch=f()end
local i,i=m(arch)
local i=nil
if l and l==true then
i=s("/bin/mv",{
"-f",o.."/v2ray_armv7",o.."/v2ctl_armv7",e
},nil,r)==0
else
i=s("/bin/mv",
{"-f",o.."/v2ray",o.."/v2ctl",e},
nil,r)==0
end
if not i or not h.access(e)then
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{
code=1,
error=a.translatef("Can't move new file to path: %s",
e)
}
end
s("/bin/chmod",{"-R","755",e})
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{code=0}
end
